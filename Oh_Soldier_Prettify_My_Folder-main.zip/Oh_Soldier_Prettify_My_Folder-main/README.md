# Oh_Soldier_Prettify_My_Folder
This can rename all the files in a folder as per our needs and as per our filetype we can set properties and then use this programme as this can reduce human workload.

