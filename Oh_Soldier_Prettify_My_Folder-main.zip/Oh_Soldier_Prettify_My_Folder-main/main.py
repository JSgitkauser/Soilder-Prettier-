print("Hello Welcome to My Programme [Oh soldier Prettify my Folder] \n"
	            "Please Mention the Following things \n"
            "A Directory - from where we will find the folder\n"
            "A File- in which the names should be there containing the folder that you don't want to rename\n"
            "A format- from which we will use that format to change their name from 1 to the number of files of that format\n"
            "Please Enter to Continue")
space = input()


soldier(r"Directory\Folder\Subfolder\Sub-sub-subfolfer",
        r"Directory\Folder\SubFolder\SubFolder\Sub Folder\demo.txt", ".png" )

print("Your Task Was Completed")
